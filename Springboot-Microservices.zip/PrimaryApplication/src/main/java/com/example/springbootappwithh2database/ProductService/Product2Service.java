package com.example.springbootappwithh2database.ProductService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.springbootappwithh2database.entity.Product2;
import com.example.springbootappwithh2database.repo.ProductRepo;

@Service
public class Product2Service {
	@Autowired
	private ProductRepo repository;
	
	@Transactional
    public List<Product2> getProducts() {
        return repository.findAll();
    }
	
	@Transactional
    public Product2 getProductById(int id) {
        return repository.findById(id).orElse(null);
    }

    @Transactional
    public Double getRatingById(int id) {
        return repository.findById(id).map(product -> product.getRating()).orElse(null);
    }

    @Transactional
    public List<Product2> getProductByName(String name) {
        return repository.findByName(name);
    }

    @Transactional
    public List<Product2> getProductByCategory(String category) {
        return repository.findByCategory(category);
    }

	@Transactional
	public Product2 saveProduct(Product2 product) {
		return repository.save(product);
	}

	@Transactional
	public List<Product2> saveProducts(List<Product2> products) {
		return repository.saveAll(products);
	}

	@Transactional
	public String deleteProduct(int id) {
		repository.deleteById(id);
		return "product removed !! " + id;
	}

	@Transactional
	public Product2 updateProduct(Product2 product) {
		Product2 existingProduct = repository.findById(product.getId()).orElse(null);
		if (existingProduct != null) {
			existingProduct.setName(product.getName());
			existingProduct.setCategory(product.getCategory());
			existingProduct.setPrice(product.getPrice());
			existingProduct.setDescription(product.getDescription());
			existingProduct.setRating(product.getRating());
			return repository.save(existingProduct);
		} else {
			return null;
		}
	}
}

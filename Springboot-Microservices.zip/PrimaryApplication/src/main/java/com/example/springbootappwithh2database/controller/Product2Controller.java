package com.example.springbootappwithh2database.controller;

import com.example.springbootappwithh2database.ProductService.Product2Service;
import com.example.springbootappwithh2database.entity.Product2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Validated
@RequestMapping("/admin")
public class Product2Controller {

	@Autowired
	private Product2Service service;

	@GetMapping("/products")
	public ResponseEntity<List<Product2>> findAllProducts() {
		try {
			List<Product2> products = service.getProducts();
			if (products.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(products, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/productById/{id}")
    public ResponseEntity<Product2> findProductById(@PathVariable int id) {
        try {
            Product2 product = service.getProductById(id);
            if (product != null) {
                return new ResponseEntity<>(product, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/productByName/{name}")
    public ResponseEntity<List<Product2>> findProductByName(@PathVariable String name) {
        try {
            List<Product2> products = service.getProductByName(name);
            if (!products.isEmpty()) {
                return new ResponseEntity<>(products, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/productByCategory/{category}")
    public ResponseEntity<List<Product2>> findProductByCategory(@PathVariable String category) {
        try {
            List<Product2> products = service.getProductByCategory(category);
            if (!products.isEmpty()) {
                return new ResponseEntity<>(products, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/ratingById/{id}")
    public ResponseEntity<Double> findRatingById(@PathVariable int id) {
        try {
            Double rating = service.getRatingById(id);
            if (rating != null) {
                return new ResponseEntity<>(rating, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

	@PostMapping("/addProduct")
	public ResponseEntity<Product2> addProduct(@Validated @RequestBody Product2 product) {
		try {
			Product2 addedProduct = service.saveProduct(product);
			return new ResponseEntity<>(addedProduct, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("/addProducts")
	public ResponseEntity<List<Product2>> addProducts(@Validated @RequestBody List<Product2> products) {
		try {
			List<Product2> addedProducts = service.saveProducts(products);
			return new ResponseEntity<>(addedProducts, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping("/update")
	public ResponseEntity<Product2> updateProduct(@Validated @RequestBody Product2 product) {
		try {
			Product2 updatedProduct = service.updateProduct(product);
			if (updatedProduct != null) {
				return new ResponseEntity<>(updatedProduct, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<HttpStatus> deleteProduct(@PathVariable int id) {
		try {
			String result = service.deleteProduct(id);
			if (result.equals("product removed !! " + id)) {
				return new ResponseEntity<>(HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}

package com.example.springbootappwithh2database.repo;
import com.example.springbootappwithh2database.entity.Product2;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
public interface ProductRepo extends JpaRepository<Product2,Integer> {
	List<Product2> findByName(String name);
    List<Product2> findByCategory(String category);
}

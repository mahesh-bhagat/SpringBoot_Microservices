package com.example.springbootappwithh2database;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAppWithH2DatabaseApplicationTests {

    @Test
    void contextLoads() {
    }

}

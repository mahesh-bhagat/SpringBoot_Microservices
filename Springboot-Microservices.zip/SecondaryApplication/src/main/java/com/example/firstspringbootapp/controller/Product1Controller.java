package com.example.firstspringbootapp.controller;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.example.firstspringbootapp.entity.Product;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
@RequestMapping("/users")
public class Product1Controller {

    @Autowired
    private RestTemplate restTemplate;

    public static final String SECOND_APP_BASE_URL = "http://localhost:8086/admin";

    @GetMapping("/products")
    @CircuitBreaker(name = "users", fallbackMethod = "fallbackGetAllProducts")
    public ResponseEntity<String> getAllProducts() {
        try {
            String secondAppUrl = SECOND_APP_BASE_URL + "/products";
            ResponseEntity<String> response = restTemplate.getForEntity(secondAppUrl, String.class);

            if (response.getStatusCode() == HttpStatus.NOT_FOUND) {
                return ResponseEntity.notFound().build();
            } else {
                return ResponseEntity.ok(response.getBody());
            }
        } catch (RestClientException e) {
            e.printStackTrace();
            return fallbackGetAllProducts(e);
        }
    }

    @GetMapping("/productById/{id}")
    public ResponseEntity<String> getProductById(@PathVariable int id) {
        try {
            String secondAppUrl = SECOND_APP_BASE_URL + "/productById/" + id;
            ResponseEntity<String> response = restTemplate.getForEntity(secondAppUrl, String.class);
            return ResponseEntity.ok(response.getBody());
        } catch (RestClientException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
        }
    }

    @GetMapping("/productByName/{name}")
    public ResponseEntity<String> getProductByName(@PathVariable String name) {
        try {
            String secondAppUrl = SECOND_APP_BASE_URL + "/productByName/" + name;
            ResponseEntity<String> response = restTemplate.getForEntity(secondAppUrl, String.class);
            return ResponseEntity.ok(response.getBody());
        } catch (RestClientException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
        }
    }

    @GetMapping("/productByCategory/{category}")
    public ResponseEntity<String> getProductByCategory(@PathVariable String category) {
        try {
            String secondAppUrl = SECOND_APP_BASE_URL + "/productByCategory/" + category;
            ResponseEntity<String> response = restTemplate.getForEntity(secondAppUrl, String.class);
            return ResponseEntity.ok(response.getBody());
        } catch (RestClientException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
        }
    }

    @GetMapping("/ratingById/{id}")
    public ResponseEntity<String> getRatingById(@PathVariable int id) {
        try {
            String secondAppUrl = SECOND_APP_BASE_URL + "/ratingById/" + id;
            ResponseEntity<String> response = restTemplate.getForEntity(secondAppUrl, String.class);
            return ResponseEntity.ok(response.getBody());
        } catch (RestClientException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
        }
    }

    public ResponseEntity<String> fallbackGetAllProducts(Exception e) {
        Product dummyProduct1 = new Product(1, "Dummy Product 1", "Category 1", 19.99, "This is a dummy product.", 4.5);
        Product dummyProduct2 = new Product(2, "Dummy Product 2", "Category 2", 29.99, "Another dummy product.", 3.8);
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String dummyProductsJson = objectMapper.writeValueAsString(Arrays.asList(dummyProduct1, dummyProduct2));
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("some products are" + dummyProductsJson);
        } catch (JsonProcessingException jsonProcessingException) {
            jsonProcessingException.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Circuit breaker fallback. Error processing dummy data.");
        }
    }
}
